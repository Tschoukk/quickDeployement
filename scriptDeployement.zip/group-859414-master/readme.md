## Rattrapage TinyInfra

Afin de réaliser les scripts pour mettre en place une infrastructure en interne.

Nous allons créer des machines virtuelles sous virtual box

Nous la nommerons "Temlate" 
Sélectionner "5 000MB"
Sélectionner "2gio" et "créer un disque dur virtuel maintenant"
cliquez sur "créer"
Sélectionner "VDI"
Cochez "dynamiquement alloué"
Sélectionner "2gio"
Puis, cliquez sur "créer"


## Installation de la VM template 

Démarrez la VM et lors de l'installation effectuez les choix suivants :
- language : English(USA)
- clavier : Français
- hostname : debian
- domaine : j'ai laissé blanc
- zone horaire : Eastern
- Partitioning method : Guided - use the entire disk
- Partitioning scheme : All files in one partition (recommended for new users)
- Finish partitioning : oui
- Use a network mirror : oui
- Debian archive mirror : United States puis ftp.us.debian.org
- http proxy :laisser blanc
- Participate in the package usage survey : no
- Choose software to install : on ne coche que les 2 dernières cases 
- Grub : oui puis /dev/sda 


## Pour la VM 'GATEWAY' 

Cloner la VM "template" 2 fois en les renommant 'gateway'.
Une des VM aura une carte réseau en 'Bridge' et l'autre 'Host-Only'

Utilisez le script main.sh de dossier 'gateway'

## Pour la VM 'WEB'

Cloner la VM "template" et rennomez la 'web'
Cette VM utilisera une carte réseau 'Host-only'

Utilisez le script main.sh de dossier 'web'

## Pour la VM 'MANAGER'

Cloner la VM "template" et rennomez la 'manager'
Cette VM utilisera une carte réseau 'Host-only'

Utilisez le script main.sh de dossier 'manager'

