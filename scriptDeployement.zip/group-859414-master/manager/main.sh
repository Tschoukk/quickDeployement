#!/bin/bash

cd /etc

echo " manager.res1.local" > hostname

cd

echo " auto lo
    iface lo inet loopback
        allow hotplud ens33
        inet static address 192.168.0.3
        netmask 255.255.0.0" > etc/network/interfaces

sudo apt-get install isc-dhcp-server

cd /etc/dhcp

echo "default-lease-time 600;
    max-lease-time 7200;
    option subnet-mask 255.255.255.0;
    option broadcast-address 192.168.1.255;
    option routers 192.168.1.254;
    option domain-name-servers 192.168.1.1, 192.168.1.2;
    option domain-name "ubuntu-fr.lan";
    option ntp-servers 192.168.1.254; `

    subnet 192.168.1.0 netmask 255.255.255.0 {
      range 192.168.1.10 192.168.1.100;
      range 192.168.1.150 192.168.1.200;
    }" > dhcpd.conf

cd /etc/default

echo " INTERFACEv4="192.168.0.3" 
        INTERFACEv6="" " > isc-dhcp-server

cd

sudo service isc-dhcp-server restart