#!/bin/bash

cd /etc

echo " web.res1.local" > hostname

cd

echo "  auto lo
        iface lo inet loopback
        allow hotplud ens33
        inet static address 192.168.0.5
        netmask 255.255.0.0" > etc/network/interfaces


apt-get install nginx

mkdir -p /var/www/web.res1.local/html

touch /var/html/web.res1.local/index.html

echo "<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>Bonjour</p>
</body>
</html>" > /var/html/web.res1.local/index.html

touch /etc/nginx/sites-available/web.res1.local

echo "server {
        listen 80 default_server;
        listen [::]:80 default_server;

        root /var/html/web.res1.local/;
        index index.html index.htm index.nginx-debian.html;

        servername ;

        location / {
                try_files $uri $uri/ =404;
        }
}" /etc/nginx/sites-available/web.res1.local

cd /etc/nginx

ln -s /etc/nginx/sites-available/web.res1.local /etc/nginx/sites-enabled/

sed -i -e "s/# server_names_hash_bucket_size 64/server_names_hash_bucket_size 64/g" nginx.conf

cd



