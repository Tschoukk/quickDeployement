#!/bin/bash

cd /etc

echo " gateway.res1.local" > hosts

cd 

cd etc/network

echo " auto lo
        iface lo inet loopback
        allow hotplud ens33
        inet static address 192.168.0.2
        netmask 255.255.0.0" > interfaces

ssh-keygen -b 2048 -t rsa -q -N " "
ssh-copy-id /root/.shh/id_rsa .pub manager@192.168.0.3
ssh-copy-id /root/.shh/id_rsa .pub web@192.168.0.5

sudo apt-get update
sudo apt-get install iptables
sudo iptables -t nat -A FORWARD -i ens33 -j ACCEPT
sudo iptables -t nat -A POSTROUTING -o ens37 -j MASQUERADE
sudo apt-get install iptables-persistent
